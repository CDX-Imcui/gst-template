static int
func_not_exported (void) {
    return 99;
}
